# %object%

https://disk.yandex.ru/client/disk

---

Файлы в облачных хранилищах