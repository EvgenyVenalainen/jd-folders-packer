# %object%


```mermaid
gantt
        title Проектные работы
        dateFormat	YYYY-MM-DD
		axisFormat	%d.%m
		Цитрус				: milestone, 2001-01-01, 1d
```

>[!question]- 2001-01-01 АБВ
>В чаще юга жил бы цитрус, да он фальшивый экземпляр.
